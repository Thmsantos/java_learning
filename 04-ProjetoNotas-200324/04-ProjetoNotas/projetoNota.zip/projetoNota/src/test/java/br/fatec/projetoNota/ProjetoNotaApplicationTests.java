package br.fatec.projetoNota;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoNotaApplicationTests {

	@Test
	void contextLoads() {
	}

}
