package br.fatec.projetoNota;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoNotaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoNotaApplication.class, args);
	}

}
